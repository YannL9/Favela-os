import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

/* ═══════════════════════════════════════════════════════════════
   FAVELA OS v4 — Supabase · Auth · Sync temps réel
   Projet : REST MANAGER GYC
   yannchalono@gmail.com
═══════════════════════════════════════════════════════════════ */

const SUPABASE_URL = "https://kselzlsukvnoyixowrom.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtzZWx6bHN1a3Zub3lpeG93cm9tIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzcwOTEwMjQsImV4cCI6MjA5MjY2NzAyNH0.TgIzu5fT5qtb71lwlcU_END_iSXpOJPIg4JUYG9VrBU";
const sb = createClient(SUPABASE_URL, SUPABASE_KEY);

const FONT = "https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,400;0,700;1,400&family=DM+Mono:wght@400;500&display=swap";

const T = {
  bg:"#0c0b09",surface:"#141210",card:"#1c1915",border:"#2a2520",faint:"#3a3028",
  gold:"#d4a843",ember:"#c0522a",green:"#4a9060",red:"#b84040",blue:"#3a7abf",
  text:"#ede8de",muted:"#6a6058",
  cat:{Alcool:"#c0522a",Boisson:"#3a7abf",Viande:"#a05030",Poisson:"#2a90a0",Épicerie:"#d4a843",Légume:"#4a9060",Crèmerie:"#b09070",Cocktail:"#7a5abf"},
};

const g = {
  flex:(d="row",gap=0,a="center")=>({display:"flex",flexDirection:d,gap,alignItems:a}),
  grid:(cols,gap=16)=>({display:"grid",gridTemplateColumns:cols,gap}),
  card:(x={})=>({background:T.card,border:`1px solid ${T.border}`,borderRadius:10,padding:20,...x}),
  inp:(x={})=>({background:T.surface,border:`1px solid ${T.border}`,borderRadius:6,padding:"8px 12px",color:T.text,fontFamily:"inherit",fontSize:12,outline:"none",width:"100%",boxSizing:"border-box",...x}),
  btn:(v="ghost",x={})=>({padding:"8px 16px",border:"none",cursor:"pointer",borderRadius:7,fontFamily:"inherit",fontSize:11,letterSpacing:.8,fontWeight:600,textTransform:"uppercase",transition:"all .15s",
    background:v==="gold"?T.gold:v==="ember"?T.ember:v==="green"?T.green:v==="red"?T.red:v==="blue"?T.blue:"transparent",
    color:["gold","ember","green","red","blue"].includes(v)?(v==="gold"?T.bg:T.text):T.muted,
    border:`1px solid ${v==="gold"?T.gold:v==="ember"?T.ember:v==="green"?T.green:v==="red"?T.red:v==="blue"?T.blue:T.border}`,...x}),
  badge:(c,x={})=>({display:"inline-flex",alignItems:"center",gap:3,padding:"2px 7px",borderRadius:4,fontSize:10,background:c+"22",color:c,fontWeight:700,letterSpacing:.8,...x}),
  tag:(c)=>({display:"inline-block",padding:"2px 7px",borderRadius:3,fontSize:9,letterSpacing:1,fontWeight:700,textTransform:"uppercase",background:c+"33",color:c,border:`1px solid ${c}44`}),
  TH:{fontSize:9,letterSpacing:1.8,color:"#6a6058",textAlign:"left",padding:"8px 10px",borderBottom:"1px solid #2a2520",textTransform:"uppercase",whiteSpace:"nowrap"},
  TD:{padding:"9px 10px",fontSize:12,borderBottom:"1px solid #2a252018"},
  sec:{fontFamily:"'Fraunces',serif",fontSize:12,color:"#d4a843",letterSpacing:2,textTransform:"uppercase",marginBottom:16},
};

const fmt = n => n!=null ? Number(n).toLocaleString("fr-FR",{minimumFractionDigits:2,maximumFractionDigits:2})+" €" : "—";
const pct = n => n!=null ? Number(n).toFixed(1)+" %" : "—";
const today = () => new Date().toISOString().split("T")[0];

const CATS = ["Alcool","Boisson","Viande","Poisson","Épicerie","Légume","Crèmerie","Cocktail"];
const FOURS = ["Metro","Pomona","Brake","Boulanger local"];
const UNITES = ["kg","L","pièce","bouteille","botte","boîte","cl"];

const TABS = [
  {id:"dashboard",label:"Dashboard",icon:"◈"},
  {id:"scanner",label:"Scanner",icon:"⊡"},
  {id:"ventes",label:"Ventes",icon:"⊕"},
  {id:"mercuriale",label:"Mercuriale",icon:"≡"},
  {id:"stock",label:"Stock",icon:"◫"},
  {id:"fiches",label:"Fiches",icon:"◉"},
  {id:"inventaire",label:"Inventaire",icon:"⊞"},
  {id:"negoce",label:"Négoce",icon:"⚖"},
  {id:"commande",label:"Commande",icon:"✉"},
];

// Données démo pour le premier chargement
const DEMO_PRODUITS = [
  {nom:"Cachaça",cat:"Alcool",four:"Metro",unite:"L",prix:18.5,prix_prev:18.5,date_maj:today(),stock:4.5,seuil:2,photo:null,note:"Caipirinha"},
  {nom:"Rhum Blanc",cat:"Alcool",four:"Metro",unite:"L",prix:14.0,prix_prev:13.5,date_maj:today(),stock:3.0,seuil:1.5,photo:null,note:"Mojito, Ti Punch"},
  {nom:"Rhum Vieux",cat:"Alcool",four:"Metro",unite:"L",prix:18.0,prix_prev:18.0,date_maj:today(),stock:2.0,seuil:1,photo:null,note:"Cuba Libre"},
  {nom:"Vodka",cat:"Alcool",four:"Metro",unite:"L",prix:12.5,prix_prev:12.5,date_maj:today(),stock:3.0,seuil:1,photo:null,note:"Caïpiroska"},
  {nom:"Gin des Îles",cat:"Alcool",four:"Pomona",unite:"L",prix:22.0,prix_prev:20.0,date_maj:today(),stock:1.5,seuil:0.5,photo:null,note:"Fitzgerald"},
  {nom:"Aperol",cat:"Alcool",four:"Metro",unite:"L",prix:14.5,prix_prev:14.5,date_maj:today(),stock:2.0,seuil:0.5,photo:null,note:"Spritz da Carla"},
  {nom:"Citron vert",cat:"Légume",four:"Pomona",unite:"kg",prix:3.5,prix_prev:3.2,date_maj:today(),stock:4.0,seuil:2,photo:null,note:"Caipirinha, Mojito"},
  {nom:"Maracuja",cat:"Légume",four:"Pomona",unite:"kg",prix:6.0,prix_prev:5.5,date_maj:today(),stock:3.0,seuil:1.5,photo:null,note:"Caipirinha"},
  {nom:"Menthe fraîche",cat:"Légume",four:"Pomona",unite:"botte",prix:1.5,prix_prev:1.5,date_maj:today(),stock:5,seuil:2,photo:null,note:"Mojito"},
  {nom:"Picanha",cat:"Viande",four:"Brake",unite:"kg",prix:26.0,prix_prev:24.0,date_maj:today(),stock:5.0,seuil:2,photo:null,note:"Picanha Grelhada 28€"},
  {nom:"Entrecôte",cat:"Viande",four:"Brake",unite:"kg",prix:29.0,prix_prev:29.0,date_maj:today(),stock:6.0,seuil:2,photo:null,note:"Entrecôte 29€"},
  {nom:"Poulet filet",cat:"Viande",four:"Pomona",unite:"kg",prix:8.5,prix_prev:8.5,date_maj:today(),stock:10.0,seuil:4,photo:null,note:"Isca Frango"},
  {nom:"Crevettes brochettes",cat:"Poisson",four:"Metro",unite:"kg",prix:18.0,prix_prev:17.0,date_maj:today(),stock:4.0,seuil:1.5,photo:null,note:"Espeto 28€"},
  {nom:"Poisson du jour (filet)",cat:"Poisson",four:"Pomona",unite:"kg",prix:16.0,prix_prev:15.0,date_maj:today(),stock:6.0,seuil:2,photo:null,note:"Isca de Peixe"},
  {nom:"Haricots noirs (feijão)",cat:"Épicerie",four:"Metro",unite:"kg",prix:3.0,prix_prev:3.0,date_maj:today(),stock:8.0,seuil:3,photo:null,note:"Feijãoda"},
  {nom:"Riz brésilien",cat:"Épicerie",four:"Metro",unite:"kg",prix:2.2,prix_prev:2.2,date_maj:today(),stock:12.0,seuil:5,photo:null,note:"Accompagnement"},
  {nom:"Lait de coco",cat:"Épicerie",four:"Metro",unite:"L",prix:2.5,prix_prev:2.5,date_maj:today(),stock:6.0,seuil:2,photo:null,note:"Muqueca"},
  {nom:"Huile d'olive",cat:"Épicerie",four:"Metro",unite:"L",prix:7.0,prix_prev:6.5,date_maj:today(),stock:4.0,seuil:1.5,photo:null,note:"Alho & Olho"},
  {nom:"Roquefort",cat:"Crèmerie",four:"Metro",unite:"kg",prix:18.0,prix_prev:18.0,date_maj:today(),stock:1.5,seuil:0.5,photo:null,note:"Sauce roquefort"},
  {nom:"Crème fraîche 35%",cat:"Crèmerie",four:"Metro",unite:"L",prix:4.5,prix_prev:4.2,date_maj:today(),stock:6.0,seuil:2,photo:null,note:"Sauces"},
];

const DEMO_FICHES = [
  {nom:"Caipirinha",cat:"Cocktail",prix_vente:10,ingredients:[{produit:"Cachaça",qte:0.06,unite:"L"},{produit:"Citron vert",qte:0.08,unite:"kg"}]},
  {nom:"Picanha Grelhada",cat:"Plat",prix_vente:28,ingredients:[{produit:"Picanha",qte:0.30,unite:"kg"},{produit:"Huile d'olive",qte:0.02,unite:"L"}]},
  {nom:"Muqueca",cat:"Plat",prix_vente:24,ingredients:[{produit:"Crevettes brochettes",qte:0.15,unite:"kg"},{produit:"Poisson du jour (filet)",qte:0.15,unite:"kg"},{produit:"Lait de coco",qte:0.2,unite:"L"}]},
  {nom:"Feijãoda",cat:"Plat",prix_vente:22,ingredients:[{produit:"Haricots noirs (feijão)",qte:0.15,unite:"kg"},{produit:"Riz brésilien",qte:0.12,unite:"kg"},{produit:"Poulet filet",qte:0.12,unite:"kg"}]},
];

// ════════════════════════════════════════════════════════════════
//  LOGIN / REGISTER
// ════════════════════════════════════════════════════════════════
function Auth({onLogin}) {
  const [mode,setMode]=useState("login");
  const [email,setEmail]=useState("yannchalono@gmail.com");
  const [pass,setPass]=useState("");
  const [loading,setLoading]=useState(false);
  const [err,setErr]=useState("");
  const [msg,setMsg]=useState("");

  async function submit(e) {
    e.preventDefault();
    setLoading(true);setErr("");setMsg("");
    if(mode==="login") {
      const {data,error}=await sb.auth.signInWithPassword({email,password:pass});
      if(error)setErr(error.message);
      else onLogin(data.user);
    } else if(mode==="register") {
      const {error}=await sb.auth.signUp({email,password:pass});
      if(error)setErr(error.message);
      else setMsg("Vérifiez votre email pour confirmer votre compte.");
    } else {
      const {error}=await sb.auth.resetPasswordForEmail(email);
      if(error)setErr(error.message);
      else setMsg("Email de réinitialisation envoyé !");
    }
    setLoading(false);
  }

  return (
    <div style={{minHeight:"100vh",background:T.bg,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'DM Mono',monospace"}}>
      <style>{`@import url('${FONT}');*{box-sizing:border-box;}input::placeholder{color:#6a6058;}`}</style>
      <div style={{width:"100%",maxWidth:400,padding:24}}>
        <div style={{textAlign:"center",marginBottom:32}}>
          <div style={{fontFamily:"'Fraunces',serif",fontSize:32,fontWeight:700,color:T.gold,letterSpacing:4}}>FAVELA OS</div>
          <div style={{fontSize:10,color:T.muted,letterSpacing:2,marginTop:4}}>RESTAURANT · TAPAS · GESTION</div>
        </div>
        <div style={g.card({padding:28})}>
          <div style={{fontSize:12,color:T.gold,letterSpacing:2,textTransform:"uppercase",marginBottom:20,fontFamily:"'Fraunces',serif"}}>
            {mode==="login"?"Connexion":mode==="register"?"Créer un compte":"Mot de passe oublié"}
          </div>
          <form onSubmit={submit} style={{display:"flex",flexDirection:"column",gap:12}}>
            <div>
              <div style={{fontSize:9,color:T.muted,letterSpacing:1.5,marginBottom:4,textTransform:"uppercase"}}>Email</div>
              <input style={g.inp()} type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="votre@email.com"/>
            </div>
            {mode!=="forgot"&&(
              <div>
                <div style={{fontSize:9,color:T.muted,letterSpacing:1.5,marginBottom:4,textTransform:"uppercase"}}>Mot de passe</div>
                <input style={g.inp()} type="password" value={pass} onChange={e=>setPass(e.target.value)} required placeholder="••••••••" minLength={6}/>
              </div>
            )}
            {err&&<div style={{color:T.red,fontSize:11,padding:"8px 12px",background:T.red+"11",borderRadius:6,border:`1px solid ${T.red}33`}}>{err}</div>}
            {msg&&<div style={{color:T.green,fontSize:11,padding:"8px 12px",background:T.green+"11",borderRadius:6,border:`1px solid ${T.green}33`}}>{msg}</div>}
            <button type="submit" style={{...g.btn("gold"),padding:12,marginTop:4}} disabled={loading}>
              {loading?"⏳ Chargement…":mode==="login"?"→ Se connecter":mode==="register"?"→ Créer le compte":"→ Envoyer"}
            </button>
          </form>
          <div style={{marginTop:16,display:"flex",flexDirection:"column",gap:8,alignItems:"center"}}>
            {mode==="login"&&<>
              <button style={{...g.btn(),fontSize:10}} onClick={()=>setMode("register")}>Pas de compte ? Créer un compte</button>
              <button style={{...g.btn(),fontSize:10}} onClick={()=>setMode("forgot")}>Mot de passe oublié ?</button>
            </>}
            {mode!=="login"&&<button style={{...g.btn(),fontSize:10}} onClick={()=>setMode("login")}>← Retour connexion</button>}
          </div>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
//  ROOT APP
// ════════════════════════════════════════════════════════════════
export default function App() {
  const [user,setUser]=useState(null);
  const [loading,setLoading]=useState(true);
  const [tab,setTab]=useState("dashboard");
  const [produits,setProduits]=useState([]);
  const [fiches,setFiches]=useState([]);
  const [ventes,setVentes]=useState([]);
  const [cmdHist,setCmdHist]=useState([]);
  const [toast,setToast]=useState(null);
  const [syncing,setSyncing]=useState(false);
  const [isMobile,setIsMobile]=useState(typeof window!=="undefined"&&window.innerWidth<768);

  const showToast=useCallback((msg,color=T.green)=>{setToast({msg,color});setTimeout(()=>setToast(null),3200);},[]);

  // Auth state
  useEffect(()=>{
    sb.auth.getSession().then(({data})=>{
      setUser(data.session?.user||null);
      setLoading(false);
    });
    const {data:{subscription}}=sb.auth.onAuthStateChange((_,session)=>{
      setUser(session?.user||null);
    });
    return()=>subscription.unsubscribe();
  },[]);

  // Mobile
  useEffect(()=>{
    const h=()=>setIsMobile(window.innerWidth<768);
    window.addEventListener("resize",h);return()=>window.removeEventListener("resize",h);
  },[]);

  // Load data from Supabase
  useEffect(()=>{
    if(!user)return;
    loadAll();
  },[user]);

  async function loadAll() {
    setSyncing(true);
    const [p,f,v,c]=await Promise.all([
      sb.from("produits").select("*").order("nom"),
      sb.from("fiches").select("*").order("nom"),
      sb.from("ventes").select("*").order("created_at",{ascending:false}),
      sb.from("commandes").select("*").order("date",{ascending:false}),
    ]);
    if(p.data) setProduits(p.data);
    if(f.data) setFiches(f.data);
    if(v.data) setVentes(v.data);
    if(c.data) setCmdHist(c.data);
    // Si première connexion : insérer les données démo
    if(p.data&&p.data.length===0) await seedDemo();
    setSyncing(false);
  }

  async function seedDemo() {
    const uid=user.id;
    await sb.from("produits").insert(DEMO_PRODUITS.map(p=>({...p,user_id:uid})));
    await sb.from("fiches").insert(DEMO_FICHES.map(f=>({...f,user_id:uid})));
    const fresh=await sb.from("produits").select("*").order("nom");
    if(fresh.data)setProduits(fresh.data);
    const freshF=await sb.from("fiches").select("*").order("nom");
    if(freshF.data)setFiches(freshF.data);
    showToast("✓ Données Favela importées !");
  }

  // Realtime subscriptions
  useEffect(()=>{
    if(!user)return;
    const ch=sb.channel("favela-realtime")
      .on("postgres_changes",{event:"*",schema:"public",table:"produits"},()=>loadTable("produits",setProduits))
      .on("postgres_changes",{event:"*",schema:"public",table:"fiches"},()=>loadTable("fiches",setFiches))
      .on("postgres_changes",{event:"*",schema:"public",table:"commandes"},()=>loadTable("commandes",setCmdHist,"date",false))
      .subscribe();
    return()=>sb.removeChannel(ch);
  },[user]);

  async function loadTable(table,setter,orderBy="nom",asc=true) {
    const {data}=await sb.from(table).select("*").order(orderBy,{ascending:asc});
    if(data)setter(data);
  }

  // ── CRUD helpers ──────────────────────────────────────────────
  const upsertProduit=useCallback(async(p)=>{
    const payload={...p,user_id:user.id,prix_prev:p.prix_prev||p.prix};
    if(p.id){await sb.from("produits").update(payload).eq("id",p.id);}
    else{await sb.from("produits").insert(payload);}
    const {data}=await sb.from("produits").select("*").order("nom");
    if(data)setProduits(data);
  },[user]);

  const deleteProduit=useCallback(async(id)=>{
    await sb.from("produits").delete().eq("id",id);
    setProduits(prev=>prev.filter(p=>p.id!==id));
  },[]);

  const upsertFiche=useCallback(async(f)=>{
    const payload={...f,user_id:user.id};
    if(f.id){await sb.from("fiches").update(payload).eq("id",f.id);}
    else{await sb.from("fiches").insert(payload);}
    const {data}=await sb.from("fiches").select("*").order("nom");
    if(data)setFiches(data);
  },[user]);

  const addVente=useCallback(async(v)=>{
    const {data}=await sb.from("ventes").insert({...v,user_id:user.id}).select();
    if(data)setVentes(prev=>[data[0],...prev]);
  },[user]);

  const deleteVente=useCallback(async(id)=>{
    await sb.from("ventes").delete().eq("id",id);
    setVentes(prev=>prev.filter(v=>v.id!==id));
  },[]);

  const addCommande=useCallback(async(c)=>{
    const {data}=await sb.from("commandes").insert({...c,user_id:user.id}).select();
    if(data)setCmdHist(prev=>[data[0],...prev]);
    return data?.[0];
  },[user]);

  const updateCommande=useCallback(async(id,updates)=>{
    await sb.from("commandes").update(updates).eq("id",id);
    setCmdHist(prev=>prev.map(c=>c.id===id?{...c,...updates}:c));
  },[]);

  const deleteCommande=useCallback(async(id)=>{
    await sb.from("commandes").delete().eq("id",id);
    setCmdHist(prev=>prev.filter(c=>c.id!==id));
  },[]);

  // Mass update produits (scanner import)
  const updateProduitsMany=useCallback(async(updates)=>{
    for(const upd of updates){
      if(upd.id) await sb.from("produits").update(upd).eq("id",upd.id);
      else await sb.from("produits").insert({...upd,user_id:user.id});
    }
    const {data}=await sb.from("produits").select("*").order("nom");
    if(data)setProduits(data);
  },[user]);

  const calcFC=useCallback((fiche)=>{
    let cout=0;
    const ings=fiche.ingredients||[];
    for(const ing of ings){const p=produits.find(x=>x.nom===ing.produit);if(p)cout+=Number(p.prix)*ing.qte;}
    const pv=Number(fiche.prix_vente)||0;
    return{cout,marge:pv-cout,fc:pv>0?(cout/pv)*100:0};
  },[produits]);

  const alertesPrix=useMemo(()=>produits.filter(p=>Number(p.prix)>Number(p.prix_prev)*1.05),[produits]);
  const stockCritique=useMemo(()=>produits.filter(p=>Number(p.stock)<=Number(p.seuil)),[produits]);

  const shared={produits,fiches,ventes,cmdHist,showToast,calcFC,alertesPrix,stockCritique,user,
    upsertProduit,deleteProduit,upsertFiche,addVente,deleteVente,addCommande,updateCommande,deleteCommande,updateProduitsMany};

  if(loading) return(
    <div style={{minHeight:"100vh",background:T.bg,display:"flex",alignItems:"center",justifyContent:"center",color:T.gold,fontFamily:"'DM Mono',monospace",fontSize:12,letterSpacing:2}}>
      <style>{`@import url('${FONT}');`}</style>
      ⏳ CHARGEMENT…
    </div>
  );

  if(!user) return <Auth onLogin={u=>setUser(u)}/>;

  return (
    <div style={{minHeight:"100vh",background:T.bg,color:T.text,fontFamily:"'DM Mono','Courier New',monospace",paddingBottom:isMobile?72:0}}>
      <style>{`@import url('${FONT}');*{box-sizing:border-box;}input::placeholder{color:#6a6058;}select option{background:#1c1915;}::-webkit-scrollbar{width:5px;height:5px;}::-webkit-scrollbar-thumb{background:#3a3028;border-radius:3px;}tbody tr:hover td{background:rgba(212,168,67,0.05);}button:hover{filter:brightness(1.12);}button:active{transform:scale(.97);}@keyframes slideIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}`}</style>

      {/* HEADER */}
      <header style={{background:`linear-gradient(180deg,#1a1510,${T.surface})`,borderBottom:`1px solid ${T.border}`,padding:"12px 20px",display:"flex",alignItems:"center",gap:12,position:"sticky",top:0,zIndex:200}}>
        <div>
          <div style={{fontFamily:"'Fraunces',serif",fontSize:18,fontWeight:700,color:T.gold,letterSpacing:3}}>FAVELA OS</div>
          <div style={{fontSize:8,color:T.muted,letterSpacing:2}}>
            {syncing?"⟳ SYNCHRONISATION…":"● CONNECTÉ · SUPABASE"}
          </div>
        </div>
        <div style={{display:"flex",gap:6,alignItems:"center"}}>
          {alertesPrix.length>0&&<span style={g.badge(T.red)}>⚠ {alertesPrix.length} hausse{alertesPrix.length>1?"s":""}</span>}
          {stockCritique.length>0&&<span style={g.badge(T.ember)}>◈ {stockCritique.length} critique{stockCritique.length>1?"s":""}</span>}
        </div>
        <div style={{marginLeft:"auto",display:"flex",gap:8,alignItems:"center"}}>
          <span style={{fontSize:10,color:T.muted}}>{user.email}</span>
          <button style={{...g.btn(),padding:"5px 10px",fontSize:9}} onClick={()=>sb.auth.signOut()}>Déconnexion</button>
          {/* Nav desktop */}
          <nav style={{display:isMobile?"none":"flex",gap:2}}>
            {TABS.map(t=>(
              <button key={t.id} onClick={()=>setTab(t.id)} style={{padding:"7px 11px",border:"none",cursor:"pointer",borderRadius:6,fontFamily:"inherit",fontSize:9,letterSpacing:.8,textTransform:"uppercase",background:tab===t.id?T.gold:"transparent",color:tab===t.id?T.bg:T.muted,fontWeight:tab===t.id?700:400,transition:"all .15s"}}>
                {t.icon} {t.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Toast */}
      {toast&&<div style={{position:"fixed",bottom:88,right:20,zIndex:9999,background:toast.color,color:"#000",padding:"11px 20px",borderRadius:8,fontWeight:700,fontSize:11,letterSpacing:1.2,boxShadow:"0 8px 32px rgba(0,0,0,.6)",textTransform:"uppercase",animation:"slideIn .2s ease"}}>{toast.msg}</div>}

      {/* Main */}
      <main style={{padding:"20px",maxWidth:1400,margin:"0 auto"}}>
        {tab==="dashboard"&&<Dashboard {...shared}/>}
        {tab==="scanner"&&<Scanner {...shared}/>}
        {tab==="ventes"&&<Ventes {...shared}/>}
        {tab==="mercuriale"&&<Mercuriale {...shared}/>}
        {tab==="stock"&&<Stock {...shared}/>}
        {tab==="fiches"&&<Fiches {...shared}/>}
        {tab==="inventaire"&&<Inventaire {...shared}/>}
        {tab==="negoce"&&<Negoce {...shared}/>}
        {tab==="commande"&&<Commande {...shared}/>}
      </main>

      {/* Mobile nav */}
      <nav style={{display:isMobile?"flex":"none",position:"fixed",bottom:0,left:0,right:0,background:T.surface,borderTop:`1px solid ${T.border}`,zIndex:300,overflowX:"auto"}}>
        {TABS.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:"0 0 auto",padding:"10px 10px",border:"none",cursor:"pointer",background:"transparent",color:tab===t.id?T.gold:T.muted,fontFamily:"inherit",fontSize:7.5,letterSpacing:.5,textTransform:"uppercase",display:"flex",flexDirection:"column",alignItems:"center",gap:3}}>
            <span style={{fontSize:15}}>{t.icon}</span>{t.label}
          </button>
        ))}
      </nav>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
//  DASHBOARD
// ════════════════════════════════════════════════════════════════
function Dashboard({produits,fiches,calcFC,alertesPrix,stockCritique,ventes,cmdHist}) {
  const avgFC=fiches.length?fiches.reduce((a,f)=>a+calcFC(f).fc,0)/fiches.length:0;
  const valeurStock=produits.reduce((a,p)=>a+Number(p.prix)*Number(p.stock),0);
  const caTotal=ventes.reduce((a,v)=>a+Number(v.ca_ht),0);
  const totalCmds=cmdHist.reduce((a,c)=>a+Number(c.total),0);
  const cmdByFour=cmdHist.reduce((acc,c)=>{acc[c.four]=(acc[c.four]||0)+Number(c.total);return acc;},{});

  return (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14}}>
        {[
          {l:"Produits référencés",v:produits.length,c:T.gold,s:"dans la mercuriale"},
          {l:"Food Cost moyen",v:pct(avgFC),c:avgFC>35?T.red:avgFC>28?T.ember:T.green,s:avgFC>35?"⚠ À corriger":"✓ Correct"},
          {l:"Alertes prix",v:alertesPrix.length,c:alertesPrix.length?T.red:T.green,s:alertesPrix.length?"Hausses > 5%":"Stables"},
          {l:"Valeur stock",v:fmt(valeurStock),c:T.blue,s:`${stockCritique.length} critique${stockCritique.length!==1?"s":""}`},
        ].map(k=>(
          <div key={k.l} style={g.card({display:"flex",flexDirection:"column",gap:6,padding:16})}>
            <div style={{fontFamily:"'Fraunces',serif",fontSize:22,fontWeight:700,color:k.c}}>{k.v}</div>
            <div style={{fontSize:9,color:T.muted,letterSpacing:1.5,textTransform:"uppercase"}}>{k.l}</div>
            <div style={{fontSize:10,color:k.c+"cc"}}>{k.s}</div>
          </div>
        ))}
      </div>

      {(caTotal>0||totalCmds>0)&&(
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:14}}>
          {[
            {l:"CA Ventes importé",v:fmt(caTotal),c:T.green,s:`${ventes.length} période${ventes.length>1?"s":""}`,show:caTotal>0},
            {l:"Volume achats",v:fmt(totalCmds),c:T.blue,s:`${cmdHist.length} commandes`,show:totalCmds>0},
            {l:"Ratio achats / CA",v:caTotal>0?pct(totalCmds/caTotal*100):"—",c:totalCmds/caTotal>0.35?T.red:T.gold,s:"Food cost global",show:caTotal>0&&totalCmds>0},
          ].filter(k=>k.show).map(k=>(
            <div key={k.l} style={g.card({display:"flex",flexDirection:"column",gap:6,padding:16,border:`1px solid ${k.c}33`})}>
              <div style={{fontFamily:"'Fraunces',serif",fontSize:20,fontWeight:700,color:k.c}}>{k.v}</div>
              <div style={{fontSize:9,color:T.muted,letterSpacing:1.5,textTransform:"uppercase"}}>{k.l}</div>
              <div style={{fontSize:10,color:k.c+"cc"}}>{k.s}</div>
            </div>
          ))}
        </div>
      )}

      <div style={{display:"grid",gridTemplateColumns:"1.3fr 1fr",gap:18}}>
        <div style={g.card()}>
          <div style={g.sec}>Food Cost par plat & cocktail</div>
          <table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead><tr>{["Plat","Coût","Vente","Marge","FC%","Prix conseillé"].map(h=><th key={h} style={g.TH}>{h}</th>)}</tr></thead>
            <tbody>
              {fiches.map(f=>{
                const {cout,marge,fc}=calcFC(f);
                const pv=Number(f.prix_vente);
                return(
                  <tr key={f.id}>
                    <td style={{...g.TD,fontWeight:600}}>{f.nom}</td>
                    <td style={g.TD}>{fmt(cout)}</td>
                    <td style={g.TD}>{fmt(pv)}</td>
                    <td style={{...g.TD,color:marge>0?T.green:T.red,fontWeight:600}}>{fmt(marge)}</td>
                    <td style={g.TD}><span style={g.badge(fc>35?T.red:fc>28?T.ember:T.green)}>{pct(fc)}</span></td>
                    <td style={g.TD}><span style={{fontSize:10,color:T.gold}}>28%→{cout>0?fmt(Math.ceil(cout/0.28)):"-"}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <div style={g.card({padding:16})}>
            <div style={g.sec}>⚠ Hausses fournisseurs</div>
            {alertesPrix.length===0?<div style={{color:T.green,fontSize:12}}>✓ Aucune hausse</div>:alertesPrix.slice(0,5).map(p=>{
              const d=((Number(p.prix)-Number(p.prix_prev))/Number(p.prix_prev)*100);
              return(<div key={p.id} style={{display:"flex",gap:8,padding:"6px 0",borderBottom:`1px solid ${T.border}22`,fontSize:12}}>
                <span style={{flex:1,fontSize:11}}>{p.nom}</span>
                <span style={{color:T.muted,fontSize:10}}>{fmt(p.prix_prev)}</span>
                <span style={{color:T.red,fontWeight:700}}>{fmt(p.prix)}</span>
                <span style={g.badge(T.red)}>+{d.toFixed(1)}%</span>
              </div>);
            })}
          </div>
          <div style={g.card({padding:16})}>
            <div style={g.sec}>◈ Stock critique</div>
            {stockCritique.length===0?<div style={{color:T.green,fontSize:12}}>✓ Tous OK</div>:stockCritique.slice(0,5).map(p=>(
              <div key={p.id} style={{display:"flex",gap:8,padding:"6px 0",borderBottom:`1px solid ${T.border}22`,fontSize:12}}>
                <span style={{flex:1,fontSize:11}}>{p.nom}</span>
                <span style={{color:T.red,fontWeight:700}}>{p.stock} {p.unite}</span>
                <span style={{color:T.muted,fontSize:10}}>/ {p.seuil}</span>
              </div>
            ))}
          </div>
          <div style={g.card({padding:16})}>
            <div style={g.sec}>Volume achats / fournisseur</div>
            {Object.entries(cmdByFour).sort((a,b)=>b[1]-a[1]).map(([four,vol])=>{
              const part=totalCmds>0?vol/totalCmds*100:0;
              return(<div key={four} style={{marginBottom:10}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <span style={{fontSize:11}}>{four}</span>
                  <span style={{fontSize:11,color:T.gold,fontWeight:700}}>{fmt(vol)}</span>
                </div>
                <div style={{height:5,background:T.faint,borderRadius:3}}><div style={{width:`${part}%`,height:"100%",background:T.gold,borderRadius:3}}/></div>
                <div style={{fontSize:9,color:T.muted,marginTop:2}}>{part.toFixed(1)}% du total</div>
              </div>);
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
//  SCANNER
// ════════════════════════════════════════════════════════════════
function Scanner({produits,updateProduitsMany,showToast}) {
  const [scanning,setScanning]=useState(false);
  const [result,setResult]=useState(null);
  const fileRef=useRef();

  async function analyse(b64,mimeType) {
    setScanning(true);setResult(null);
    try {
      const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,messages:[{role:"user",content:[{type:"image",source:{type:"base64",media_type:mimeType,data:b64}},{type:"text",text:'Analyse cette facture. JSON uniquement: {"fournisseur":"nom","date":"YYYY-MM-DD","produits":[{"nom":"exact","qte":0.0,"unite":"kg|L|pièce|bouteille","prixUnit":0.0,"cat":"Alcool|Boisson|Viande|Poisson|Épicerie|Légume|Crèmerie|Cocktail"}]}'}]}]})});
      const data=await res.json();
      setResult(JSON.parse(data.content.map(c=>c.text||"").join("").replace(/```json|```/g,"").trim()));
    } catch {
      setResult({fournisseur:"Metro (démo)",date:today(),produits:[
        {nom:"Rhum Blanc",qte:6,unite:"L",prixUnit:14.5,cat:"Alcool"},
        {nom:"Citron vert",qte:4,unite:"kg",prixUnit:3.9,cat:"Légume"},
        {nom:"Poulet filet",qte:8,unite:"kg",prixUnit:8.9,cat:"Viande"},
      ]});
    }
    setScanning(false);
  }

  function handleFile(e){const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=ev=>analyse(ev.target.result.split(",")[1],f.type);r.readAsDataURL(f);}

  async function importAll() {
    if(!result)return;
    const updates=[];const hausses=[];
    for(const item of result.produits){
      const ex=produits.find(p=>p.nom.toLowerCase()===item.nom.toLowerCase());
      if(ex){
        if(item.prixUnit>Number(ex.prix)*1.05)hausses.push(item.nom);
        updates.push({id:ex.id,prix_prev:ex.prix,prix:item.prixUnit,stock:Number(ex.stock)+item.qte,date_maj:result.date,four:result.fournisseur});
      } else {
        updates.push({nom:item.nom,cat:item.cat||"Épicerie",four:result.fournisseur,unite:item.unite,prix:item.prixUnit,prix_prev:item.prixUnit,date_maj:result.date,stock:item.qte,seuil:item.qte*0.3,photo:null,note:""});
      }
    }
    await updateProduitsMany(updates);
    showToast(`✓ ${result.produits.length} produits importés${hausses.length?` · ⚠ ${hausses.join(", ")}`:""}`,(hausses.length?T.ember:T.green));
    setResult(null);
  }

  return (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <div style={g.card()}>
        <div style={g.sec}>Scanner une facture</div>
        <div onClick={()=>fileRef.current.click()} style={{border:`2px dashed ${T.border}`,borderRadius:10,padding:40,textAlign:"center",cursor:"pointer",marginBottom:14,background:T.surface}}>
          <div style={{fontSize:36,marginBottom:8}}>📄</div>
          <div style={{color:T.muted,fontSize:12}}>Photo ou PDF de facture — l'IA extrait tout automatiquement</div>
          <input ref={fileRef} type="file" accept="image/*,.pdf" style={{display:"none"}} onChange={handleFile}/>
        </div>
        <div style={{display:"flex",gap:10}}>
          <button style={g.btn("gold")} onClick={()=>fileRef.current.click()}>📷 Uploader facture</button>
          <button style={g.btn()} onClick={()=>{setScanning(true);setTimeout(()=>{setResult({fournisseur:"Pomona (démo)",date:today(),produits:[{nom:"Maracuja",qte:5,unite:"kg",prixUnit:6.5,cat:"Légume"},{nom:"Citron vert",qte:8,unite:"kg",prixUnit:3.8,cat:"Légume"},{nom:"Poulet filet",qte:10,unite:"kg",prixUnit:8.9,cat:"Viande"}]});setScanning(false);},1000);}}>⚡ Démo</button>
        </div>
      </div>
      {scanning&&<div style={{...g.card(),textAlign:"center",padding:32,color:T.gold,fontSize:12,letterSpacing:2}}>⏳ ANALYSE IA…</div>}
      {result&&(
        <div style={g.card()}>
          <div style={{display:"flex",gap:12,marginBottom:14,alignItems:"flex-start"}}>
            <div><div style={g.sec}>{result.fournisseur} — {result.date}</div><div style={{fontSize:11,color:T.muted}}>{result.produits.length} produits · {fmt(result.produits.reduce((a,p)=>a+p.prixUnit*p.qte,0))}</div></div>
            <button style={{...g.btn("gold"),marginLeft:"auto"}} onClick={importAll}>↓ Importer → Supabase</button>
          </div>
          <table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead><tr>{["Produit","Cat.","Qté","Unité","Prix U.","Total"].map(h=><th key={h} style={g.TH}>{h}</th>)}</tr></thead>
            <tbody>{result.produits.map((p,i)=>{
              const ex=produits.find(x=>x.nom.toLowerCase()===p.nom.toLowerCase());
              const hausse=ex&&p.prixUnit>Number(ex.prix)*1.05;
              return(<tr key={i}>
                <td style={{...g.TD,fontWeight:600}}>{p.nom}{hausse&&<span style={{...g.badge(T.red),marginLeft:8}}>⚠ Hausse</span>}{!ex&&<span style={{...g.badge(T.blue),marginLeft:8}}>Nouveau</span>}</td>
                <td style={g.TD}><span style={g.tag(T.cat[p.cat]||T.muted)}>{p.cat}</span></td>
                <td style={g.TD}>{p.qte}</td>
                <td style={g.TD}>{p.unite}</td>
                <td style={{...g.TD,color:hausse?T.red:T.text}}>{fmt(p.prixUnit)}</td>
                <td style={{...g.TD,color:T.gold,fontWeight:600}}>{fmt(p.prixUnit*p.qte)}</td>
              </tr>);
            })}</tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
//  MERCURIALE
// ════════════════════════════════════════════════════════════════
function Mercuriale({produits,upsertProduit,deleteProduit,showToast}) {
  const [search,setSearch]=useState("");
  const [catF,setCatF]=useState("Tous");
  const [fourF,setFourF]=useState("Tous");
  const [editId,setEditId]=useState(null);
  const [editVal,setEditVal]=useState("");
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({nom:"",cat:"Épicerie",four:"Metro",unite:"kg",prix:"",seuil:"",note:""});
  const fileRef=useRef();
  const [photoTarget,setPhotoTarget]=useState(null);

  const fours=["Tous",...new Set(produits.map(p=>p.four))];
  const filtered=produits.filter(p=>(catF==="Tous"||p.cat===catF)&&(fourF==="Tous"||p.four===fourF)&&p.nom.toLowerCase().includes(search.toLowerCase()));

  function handlePhoto(e){
    const f=e.target.files[0];if(!f||!photoTarget)return;
    const r=new FileReader();
    r.onload=async ev=>{
      await upsertProduit({...produits.find(p=>p.id===photoTarget),photo:ev.target.result});
      showToast("Photo sauvegardée ✓");setPhotoTarget(null);
    };
    r.readAsDataURL(f);
  }

  async function saveEdit(id){
    const nv=parseFloat(String(editVal).replace(",","."));if(isNaN(nv))return;
    const p=produits.find(x=>x.id===id);
    await upsertProduit({...p,prix_prev:p.prix,prix:nv,date_maj:today()});
    setEditId(null);showToast("Prix mis à jour → Supabase ✓");
  }

  async function addProduit(){
    if(!form.nom||!form.prix)return;
    const prix=parseFloat(String(form.prix).replace(",","."));
    await upsertProduit({...form,prix,prix_prev:prix,date_maj:today(),stock:0,seuil:parseFloat(form.seuil)||0,photo:null});
    setForm({nom:"",cat:"Épicerie",four:"Metro",unite:"kg",prix:"",seuil:"",note:""});
    setShowAdd(false);showToast(`${form.nom} ajouté ✓`);
  }

  function exportCSV(){
    const rows=[["Nom","Catégorie","Fournisseur","Unité","Prix actuel","Prix précédent","Stock","Seuil","Date","Note"]];
    produits.forEach(p=>rows.push([p.nom,p.cat,p.four,p.unite,p.prix,p.prix_prev,p.stock,p.seuil,p.date_maj,p.note]));
    const csv="\uFEFF"+rows.map(r=>r.map(v=>`"${v}"`).join(";")).join("\n");
    const a=Object.assign(document.createElement("a"),{href:URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"})),download:`mercuriale_favela_${today()}.csv`});
    a.click();showToast("CSV exporté ✓");
  }

  return (
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <input type="file" accept="image/*" capture="environment" ref={fileRef} style={{display:"none"}} onChange={handlePhoto}/>
      <div style={g.card({padding:12})}>
        <div style={{display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
          <input style={{...g.inp(),maxWidth:180}} placeholder="🔍 Rechercher…" value={search} onChange={e=>setSearch(e.target.value)}/>
          <select style={{...g.inp(),maxWidth:140}} value={catF} onChange={e=>setCatF(e.target.value)}>{["Tous",...CATS].map(c=><option key={c}>{c}</option>)}</select>
          <select style={{...g.inp(),maxWidth:140}} value={fourF} onChange={e=>setFourF(e.target.value)}>{fours.map(f=><option key={f}>{f}</option>)}</select>
          <span style={{color:T.muted,fontSize:11}}>{filtered.length} produits</span>
          <div style={{display:"flex",gap:6,marginLeft:"auto"}}>
            <button style={g.btn()} onClick={()=>setShowAdd(!showAdd)}>{showAdd?"✕":"+ Ajouter"}</button>
            <button style={g.btn("gold")} onClick={exportCSV}>↓ CSV</button>
          </div>
        </div>
        {showAdd&&(
          <div style={{marginTop:12,paddingTop:12,borderTop:`1px solid ${T.border}`,display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr 1fr 1fr auto",gap:8,alignItems:"end"}}>
            {[{l:"Nom *",k:"nom",t:"text"},{l:"Prix € *",k:"prix",t:"number"},{l:"Seuil",k:"seuil",t:"number"},{l:"Note",k:"note",t:"text"}].map(f=>(
              <div key={f.k}><div style={{fontSize:9,color:T.muted,letterSpacing:1.2,marginBottom:4,textTransform:"uppercase"}}>{f.l}</div><input style={g.inp()} type={f.t} value={form[f.k]} onChange={e=>setForm({...form,[f.k]:e.target.value})}/></div>
            ))}
            <div><div style={{fontSize:9,color:T.muted,letterSpacing:1.2,marginBottom:4,textTransform:"uppercase"}}>Catégorie</div><select style={g.inp()} value={form.cat} onChange={e=>setForm({...form,cat:e.target.value})}>{CATS.map(c=><option key={c}>{c}</option>)}</select></div>
            <div><div style={{fontSize:9,color:T.muted,letterSpacing:1.2,marginBottom:4,textTransform:"uppercase"}}>Fournisseur</div><select style={g.inp()} value={form.four} onChange={e=>setForm({...form,four:e.target.value})}>{FOURS.map(f=><option key={f}>{f}</option>)}</select></div>
            <button style={{...g.btn("gold"),alignSelf:"flex-end"}} onClick={addProduit}>✓</button>
          </div>
        )}
      </div>
      <div style={g.card({padding:0,overflow:"hidden"})}>
        <div style={{overflowX:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead><tr style={{background:T.surface}}>
              {["Photo","Produit","Catégorie","Fournisseur","Unité","Prix préc.","Prix actuel","Variation","Stock","Date","Note",""].map(h=><th key={h} style={g.TH}>{h}</th>)}
            </tr></thead>
            <tbody>{filtered.map(p=>{
              const delta=((Number(p.prix)-Number(p.prix_prev))/Number(p.prix_prev))*100;
              const hausse=Number(p.prix)>Number(p.prix_prev)*1.05;
              const critique=Number(p.stock)<=Number(p.seuil);
              const isEditing=editId===p.id;
              return(<tr key={p.id}>
                <td style={g.TD}><div onClick={()=>{setPhotoTarget(p.id);fileRef.current.click();}} style={{width:34,height:34,borderRadius:5,overflow:"hidden",background:T.surface,border:`1px solid ${T.border}`,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",fontSize:12}}>{p.photo?<img src={p.photo} style={{width:"100%",height:"100%",objectFit:"cover"}}/>:"📷"}</div></td>
                <td style={{...g.TD,fontWeight:600,maxWidth:150}}>{p.nom}</td>
                <td style={g.TD}><span style={g.tag(T.cat[p.cat]||T.muted)}>{p.cat}</span></td>
                <td style={{...g.TD,color:T.muted,fontSize:11}}>{p.four}</td>
                <td style={{...g.TD,color:T.muted,fontSize:11}}>{p.unite}</td>
                <td style={{...g.TD,color:T.muted,textDecoration:hausse?"line-through":"none",fontSize:11}}>{fmt(p.prix_prev)}</td>
                <td style={g.TD}>{isEditing
                  ?<div style={{display:"flex",gap:4}}><input autoFocus style={{...g.inp(),width:78}} value={editVal} onChange={e=>setEditVal(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")saveEdit(p.id);if(e.key==="Escape")setEditId(null);}}/><button style={{...g.btn("gold"),padding:"4px 8px"}} onClick={()=>saveEdit(p.id)}>✓</button></div>
                  :<span style={{color:hausse?T.red:T.text,fontWeight:hausse?700:400}}>{fmt(p.prix)}</span>}
                </td>
                <td style={g.TD}>{Math.abs(delta)>0.5?<span style={g.badge(delta>0?T.red:T.green)}>{delta>0?"▲":"▼"}{Math.abs(delta).toFixed(1)}%</span>:"—"}</td>
                <td style={g.TD}><span style={{color:critique?T.red:T.muted,fontWeight:critique?700:400,fontSize:11}}>{p.stock} {p.unite}{critique?" ⚠":""}</span></td>
                <td style={{...g.TD,fontSize:9,color:T.muted}}>{p.date_maj}</td>
                <td style={{...g.TD,fontSize:10,color:T.muted,maxWidth:120}}>{p.note}</td>
                <td style={g.TD}><button style={{...g.btn(),padding:"3px 9px",fontSize:9}} onClick={()=>isEditing?setEditId(null):(setEditId(p.id),setEditVal(p.prix))}>{isEditing?"✕":"✏"}</button></td>
              </tr>);
            })}</tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
//  STOCK
// ════════════════════════════════════════════════════════════════
function Stock({produits,upsertProduit,showToast}) {
  const [search,setSearch]=useState("");
  const [catF,setCatF]=useState("Tous");
  const critiques=produits.filter(p=>Number(p.stock)<=Number(p.seuil));
  const filtered=produits.filter(p=>(catF==="Tous"||p.cat===catF)&&p.nom.toLowerCase().includes(search.toLowerCase()));

  async function setStock(p,v){const nv=parseFloat(String(v).replace(",","."));if(!isNaN(nv))await upsertProduit({...p,stock:Math.max(0,nv)});}
  async function setSeuil(p,v){const nv=parseFloat(String(v).replace(",","."));if(!isNaN(nv))await upsertProduit({...p,seuil:nv});}
  async function addStock(p,d){await upsertProduit({...p,stock:Math.max(0,parseFloat((Number(p.stock)+d).toFixed(2)))});}

  return (
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      {critiques.length>0&&(
        <div style={g.card({background:T.red+"11",border:`1px solid ${T.red}44`,padding:14})}>
          <div style={{color:T.red,fontSize:10,fontWeight:700,letterSpacing:1.5,marginBottom:8,textTransform:"uppercase"}}>⚠ STOCKS CRITIQUES</div>
          <div style={{display:"flex",flexWrap:"wrap",gap:6}}>{critiques.map(p=><span key={p.id} style={g.badge(T.red)}>{p.nom} : {p.stock} / {p.seuil} {p.unite}</span>)}</div>
        </div>
      )}
      <div style={g.card({padding:12})}>
        <div style={{display:"flex",gap:8}}>
          <input style={{...g.inp(),maxWidth:200}} placeholder="🔍 Rechercher…" value={search} onChange={e=>setSearch(e.target.value)}/>
          <select style={{...g.inp(),maxWidth:150}} value={catF} onChange={e=>setCatF(e.target.value)}>{["Tous",...CATS].map(c=><option key={c}>{c}</option>)}</select>
        </div>
      </div>
      <div style={g.card({padding:0,overflow:"hidden"})}>
        <table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead><tr style={{background:T.surface}}>{["Produit","Cat.","Fournisseur","Stock","Seuil","Unité","Statut","Ajuster"].map(h=><th key={h} style={g.TH}>{h}</th>)}</tr></thead>
          <tbody>{filtered.map(p=>{
            const crit=Number(p.stock)<=Number(p.seuil);const bas=Number(p.stock)<=Number(p.seuil)*1.5&&!crit;
            return(<tr key={p.id}>
              <td style={{...g.TD,fontWeight:600}}>{p.nom}</td>
              <td style={g.TD}><span style={g.tag(T.cat[p.cat]||T.muted)}>{p.cat}</span></td>
              <td style={{...g.TD,color:T.muted,fontSize:11}}>{p.four}</td>
              <td style={g.TD}><input style={{...g.inp(),width:80,color:crit?T.red:T.text,fontWeight:crit?700:400}} type="number" value={p.stock} onChange={e=>setStock(p,e.target.value)}/></td>
              <td style={g.TD}><input style={{...g.inp(),width:70}} type="number" value={p.seuil} onChange={e=>setSeuil(p,e.target.value)}/></td>
              <td style={{...g.TD,color:T.muted}}>{p.unite}</td>
              <td style={g.TD}><span style={g.badge(crit?T.red:bas?T.ember:T.green)}>{crit?"⚠ Critique":bas?"~ Bas":"✓ OK"}</span></td>
              <td style={g.TD}><div style={{display:"flex",gap:5}}><button style={{...g.btn(),padding:"3px 10px"}} onClick={()=>addStock(p,-1)}>−</button><button style={{...g.btn("green"),padding:"3px 10px"}} onClick={()=>addStock(p,1)}>+</button></div></td>
            </tr>);
          })}</tbody>
        </table>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
//  FICHES
// ════════════════════════════════════════════════════════════════
function Fiches({fiches,upsertFiche,produits,showToast,calcFC}) {
  const [selId,setSelId]=useState(fiches[0]?.id);
  const fiche=fiches.find(f=>f.id===selId);
  const [edit,setEdit]=useState(null);

  useEffect(()=>{if(fiche)setEdit({...fiche,ingredients:Array.isArray(fiche.ingredients)?[...fiche.ingredients]:[]});},[selId,fiches.length]);

  async function save(){await upsertFiche(edit);showToast("Fiche sauvegardée → Supabase ✓");}
  async function newFiche(){const f={nom:"Nouveau plat",cat:"Plat",prix_vente:0,ingredients:[]};await upsertFiche(f);showToast("Nouvelle fiche créée ✓");}
  const addIng=()=>setEdit({...edit,ingredients:[...(edit.ingredients||[]),{produit:"",qte:0,unite:"kg"}]});
  const updIng=(i,k,v)=>{const ings=[...(edit.ingredients||[])];ings[i]={...ings[i],[k]:k==="qte"?parseFloat(v)||0:v};setEdit({...edit,ingredients:ings});};
  const delIng=i=>setEdit({...edit,ingredients:(edit.ingredients||[]).filter((_,j)=>j!==i)});

  const {cout,marge,fc}=edit?calcFC(edit):{cout:0,marge:0,fc:0};

  return (
    <div style={{display:"grid",gridTemplateColumns:"260px 1fr",gap:18}}>
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        <button style={{...g.btn("gold"),width:"100%",padding:10}} onClick={newFiche}>+ Nouvelle fiche</button>
        {fiches.map(f=>{const {fc:ffc}=calcFC(f);return(
          <div key={f.id} onClick={()=>setSelId(f.id)} style={g.card({cursor:"pointer",padding:"12px 14px",background:selId===f.id?T.gold+"18":T.card,border:`1px solid ${selId===f.id?T.gold+"55":T.border}`})}>
            <div style={{fontSize:12,fontWeight:600,marginBottom:4}}>{f.nom}</div>
            <div style={{display:"flex",gap:6}}><span style={g.tag(T.cat[f.cat]||T.muted)}>{f.cat}</span><span style={g.badge(ffc>35?T.red:ffc>28?T.ember:T.green)}>{pct(ffc)}</span></div>
            <div style={{fontSize:9,color:T.muted,marginTop:4}}>{fmt(f.prix_vente)} · {(f.ingredients||[]).length} ing.</div>
          </div>
        );})}
      </div>
      {edit&&(
        <div style={g.card()}>
          <div style={{display:"flex",gap:10,marginBottom:16,alignItems:"center"}}>
            <div style={g.sec}>Fiche technique</div>
            <button style={{...g.btn("gold"),marginLeft:"auto"}} onClick={save}>✓ Sauvegarder → Supabase</button>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr auto",gap:10,marginBottom:14}}>
            <div><div style={{fontSize:9,color:T.muted,letterSpacing:1.5,marginBottom:4,textTransform:"uppercase"}}>Nom</div><input style={g.inp()} value={edit.nom} onChange={e=>setEdit({...edit,nom:e.target.value})}/></div>
            <div style={{display:"flex",gap:10,alignItems:"flex-end"}}>
              <div><div style={{fontSize:9,color:T.muted,letterSpacing:1.5,marginBottom:4,textTransform:"uppercase"}}>Prix vente €</div><input style={{...g.inp(),width:88}} type="number" value={edit.prix_vente} onChange={e=>setEdit({...edit,prix_vente:parseFloat(e.target.value)||0})}/></div>
              <div><div style={{fontSize:9,color:T.muted,letterSpacing:1.5,marginBottom:4,textTransform:"uppercase"}}>Catégorie</div><select style={{...g.inp(),width:120}} value={edit.cat} onChange={e=>setEdit({...edit,cat:e.target.value})}>{["Cocktail","Plat","Tapas","Dessert","Boisson"].map(c=><option key={c}>{c}</option>)}</select></div>
            </div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:14}}>
            {[{l:"Coût matière",v:fmt(cout),c:T.text},{l:"Marge brute",v:fmt(marge),c:marge>0?T.green:T.red},{l:"Food Cost",v:pct(fc),c:fc>35?T.red:fc>28?T.ember:T.green}].map(k=>(
              <div key={k.l} style={{background:T.surface,borderRadius:8,padding:"10px 14px",border:`1px solid ${T.border}`}}>
                <div style={{fontSize:18,fontWeight:700,color:k.c,fontFamily:"'Fraunces',serif"}}>{k.v}</div>
                <div style={{fontSize:9,color:T.muted,letterSpacing:1.5,textTransform:"uppercase"}}>{k.l}</div>
              </div>
            ))}
          </div>
          <div style={{background:T.gold+"12",borderRadius:8,padding:"10px 14px",border:`1px solid ${T.gold}33`,marginBottom:14}}>
            <div style={{fontSize:9,color:T.gold,letterSpacing:1.5,textTransform:"uppercase",marginBottom:6}}>Prix conseillé</div>
            <div style={{display:"flex",gap:16}}>
              {[[0.28,"28%"],[0.30,"30%"],[0.32,"32%"],[0.35,"35%"]].map(([fc_,label])=>(
                <div key={label} style={{textAlign:"center"}}>
                  <div style={{fontFamily:"'Fraunces',serif",fontSize:15,color:T.gold,fontWeight:700}}>{cout>0?fmt(Math.ceil(cout/fc_)):"-"}</div>
                  <div style={{fontSize:9,color:T.muted}}>FC {label}</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{display:"flex",gap:8,marginBottom:8,alignItems:"center"}}>
            <div style={{fontSize:9,color:T.muted,letterSpacing:1.8,textTransform:"uppercase"}}>Ingrédients</div>
            <button style={{...g.btn(),padding:"3px 10px",fontSize:9,marginLeft:"auto"}} onClick={addIng}>+ Ajouter</button>
          </div>
          {(edit.ingredients||[]).map((ing,i)=>{const p=produits.find(x=>x.nom===ing.produit);const cl=p?Number(p.prix)*ing.qte:0;return(
            <div key={i} style={{display:"grid",gridTemplateColumns:"2.5fr 1fr 1fr auto auto",gap:6,marginBottom:6,alignItems:"center"}}>
              <select style={g.inp()} value={ing.produit} onChange={e=>updIng(i,"produit",e.target.value)}><option value="">— Choisir —</option>{produits.map(p=><option key={p.id} value={p.nom}>{p.nom}</option>)}</select>
              <input style={g.inp()} type="number" placeholder="Qté" value={ing.qte} onChange={e=>updIng(i,"qte",e.target.value)}/>
              <select style={g.inp()} value={ing.unite} onChange={e=>updIng(i,"unite",e.target.value)}>{UNITES.map(u=><option key={u}>{u}</option>)}</select>
              <span style={{fontSize:11,color:T.gold,whiteSpace:"nowrap",minWidth:58,textAlign:"right"}}>{fmt(cl)}</span>
              <button style={{...g.btn("red"),padding:"3px 8px",fontSize:11}} onClick={()=>delIng(i)}>✕</button>
            </div>
          );})}
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
//  VENTES
// ════════════════════════════════════════════════════════════════
function Ventes({ventes,addVente,deleteVente,fiches,produits,upsertProduit,calcFC,showToast}) {
  const [parsing,setParsing]=useState(false);
  const [preview,setPreview]=useState(null);
  const fileRef=useRef();

  function parseCSV(text){
    const lines=text.split(/\r?\n/).filter(l=>l.trim());
    if(lines.length<2)throw new Error("Fichier vide");
    const sep=lines[0].includes(";")?";":lines[0].includes("\t")?"\t":",";
    const headers=lines[0].split(sep).map(h=>h.replace(/"/g,"").trim().toLowerCase());
    const col=cands=>{for(const c of cands){const i=headers.findIndex(h=>h.includes(c));if(i>=0)return i;}return -1;};
    const iDate=col(["date"]),iArt=col(["article","produit","libellé","nom"]),iFam=col(["famille","catégorie"]),iQte=col(["qté","qte","quantité"]),iPU=col(["pu ht","prix unit","pu"]),iCA=col(["total ht","ca ht","montant ht","total"]);
    const lignes=[];let curDate=null;
    for(let i=1;i<lines.length;i++){
      const cells=lines[i].split(sep).map(c=>c.replace(/"/g,"").trim());
      if(cells.length<2)continue;
      const dv=iDate>=0?cells[iDate]:null;
      if(dv&&dv.match(/\d{2}[/-]\d{2}[/-]\d{2,4}/))curDate=dv;
      const article=iArt>=0?cells[iArt]:cells[0];
      if(!article||article.toLowerCase().includes("total"))continue;
      const qte=iQte>=0?parseFloat(cells[iQte]?.replace(",","."))||0:1;
      const puHT=iPU>=0?parseFloat(cells[iPU]?.replace(",","."))||0:0;
      const ca=iCA>=0?parseFloat(cells[iCA]?.replace(",","."))||0:puHT*qte;
      if(qte===0&&ca===0)continue;
      lignes.push({date:curDate||today(),article,famille:iFam>=0?cells[iFam]:"",qte,puHT,ca:ca||puHT*qte});
    }
    if(lignes.length===0)throw new Error("Aucune ligne trouvée");
    const caHT=lignes.reduce((a,l)=>a+l.ca,0);
    const dates=lignes.map(l=>l.date).filter(Boolean).sort();
    return{dateMin:dates[0]||today(),dateMax:dates[dates.length-1]||today(),caHT,lignes,nbJours:new Set(lignes.map(l=>l.date)).size};
  }

  function handleFile(e){
    const f=e.target.files[0];if(!f)return;
    setParsing(true);
    const r=new FileReader();
    r.onload=async ev=>{
      try{setPreview(parseCSV(ev.target.result));showToast("✓ Fichier analysé");}
      catch(err){showToast("Erreur: "+err.message,T.red);}
      setParsing(false);
    };
    r.readAsText(f,"utf-8");
  }

  async function importVentes(){
    if(!preview)return;
    if(ventes.find(v=>v.date_min===preview.dateMin&&v.date_max===preview.dateMax)){showToast("Période déjà importée",T.ember);return;}
    // Déstockage
    for(const l of preview.lignes){
      const fiche=fiches.find(f=>f.nom.toLowerCase().includes(l.article.toLowerCase())||l.article.toLowerCase().includes(f.nom.toLowerCase()));
      if(fiche){
        for(const ing of (fiche.ingredients||[])){
          const p=produits.find(x=>x.nom===ing.produit);
          if(p)await upsertProduit({...p,stock:Math.max(0,parseFloat((Number(p.stock)-ing.qte*l.qte).toFixed(3)))});
        }
      }
    }
    await addVente({date_min:preview.dateMin,date_max:preview.dateMax,ca_ht:preview.caHT,nb_jours:preview.nbJours,lignes:preview.lignes});
    showToast("✓ Ventes importées → Supabase · Stock mis à jour");setPreview(null);
  }

  const allLignes=ventes.flatMap(v=>v.lignes||[]);
  const parArt=allLignes.reduce((acc,l)=>{if(!acc[l.article])acc[l.article]={qte:0,ca:0,famille:l.famille};acc[l.article].qte+=l.qte;acc[l.article].ca+=l.ca;return acc;},{});
  const top=Object.entries(parArt).sort((a,b)=>b[1].ca-a[1].ca);
  const caTotal=ventes.reduce((a,v)=>a+Number(v.ca_ht),0);

  return (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <div style={g.card()}>
        <div style={g.sec}>⊕ Import ventes L'Addition</div>
        <div style={{background:T.surface,borderRadius:8,padding:"12px 16px",marginBottom:14,border:`1px solid ${T.border}`}}>
          {[["1","Back-office L'Addition → Reporting"],["2","Sélectionnez la période"],["3","Export → CSV"],["4","Importez ici"]].map(([s,t])=>(
            <div key={s} style={{display:"flex",gap:8,alignItems:"center",fontSize:11,color:T.muted,marginBottom:5}}><span style={g.badge(T.gold)}>{s}</span><span>{t}</span></div>
          ))}
        </div>
        <div onClick={()=>fileRef.current.click()} style={{border:`2px dashed ${T.border}`,borderRadius:10,padding:28,textAlign:"center",cursor:"pointer",background:T.surface,marginBottom:12}}>
          <div style={{fontSize:28,marginBottom:6}}>📊</div>
          <div style={{color:T.muted,fontSize:12}}>Glissez votre export L'Addition</div>
          <input ref={fileRef} type="file" accept=".csv,.txt,.xls,.xlsx" style={{display:"none"}} onChange={handleFile}/>
        </div>
        <div style={{display:"flex",gap:10}}>
          <button style={g.btn("gold")} onClick={()=>fileRef.current.click()}>📂 Choisir fichier</button>
          <button style={g.btn()} onClick={()=>{setParsing(true);setTimeout(()=>{setPreview({dateMin:"2025-04-14",dateMax:"2025-04-20",caHT:4820.50,nbJours:7,lignes:[{date:"2025-04-14",article:"Caipirinha",famille:"Cocktails",qte:42,puHT:8.33,ca:350},{date:"2025-04-14",article:"Picanha Grelhada",famille:"Grillades",qte:19,puHT:23.33,ca:443.3},{date:"2025-04-16",article:"Feijãoda",famille:"Spécialités",qte:22,puHT:18.33,ca:403.3}]});setParsing(false);},800);}}>⚡ Démo</button>
        </div>
      </div>
      {parsing&&<div style={{...g.card(),textAlign:"center",padding:28,color:T.gold,fontSize:12,letterSpacing:2}}>⏳ ANALYSE…</div>}
      {preview&&(
        <div style={g.card({border:`1px solid ${T.green}44`})}>
          <div style={{display:"flex",gap:12,marginBottom:14,alignItems:"flex-start"}}>
            <div><div style={g.sec}>{preview.dateMin} → {preview.dateMax}</div><div style={{display:"flex",gap:8}}><span style={g.badge(T.green)}>{fmt(preview.caHT)}</span><span style={g.badge(T.blue)}>{preview.lignes.length} lignes</span></div></div>
            <div style={{display:"flex",gap:8,marginLeft:"auto"}}>
              <button style={g.btn("green")} onClick={importVentes}>✓ Importer → Supabase</button>
              <button style={{...g.btn(),fontSize:10}} onClick={()=>setPreview(null)}>✕</button>
            </div>
          </div>
          <table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead><tr>{["Date","Article","Famille","Qté","CA HT","Fiche liée"].map(h=><th key={h} style={g.TH}>{h}</th>)}</tr></thead>
            <tbody>{preview.lignes.map((l,i)=>{const fiche=fiches.find(f=>f.nom.toLowerCase().includes(l.article.toLowerCase())||l.article.toLowerCase().includes(f.nom.toLowerCase()));return(<tr key={i}><td style={{...g.TD,fontSize:10,color:T.muted}}>{l.date}</td><td style={{...g.TD,fontWeight:600}}>{l.article}</td><td style={g.TD}>{l.famille?<span style={g.tag(T.gold)}>{l.famille}</span>:"—"}</td><td style={g.TD}>{l.qte}</td><td style={{...g.TD,color:T.green,fontWeight:600}}>{fmt(l.ca)}</td><td style={g.TD}>{fiche?<span style={g.badge(T.blue)}>{fiche.nom}</span>:"—"}</td></tr>);})}</tbody>
          </table>
        </div>
      )}
      {top.length>0&&(
        <div style={g.card()}>
          <div style={g.sec}>Classement CA — {fmt(caTotal)} total</div>
          <table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead><tr>{["#","Article","Famille","Qté","CA HT","% CA","FC réel"].map(h=><th key={h} style={g.TH}>{h}</th>)}</tr></thead>
            <tbody>{top.map(([nom,data],i)=>{
              const fiche=fiches.find(f=>f.nom.toLowerCase().includes(nom.toLowerCase())||nom.toLowerCase().includes(f.nom.toLowerCase()));
              const fcR=fiche&&data.ca>0?(calcFC(fiche).cout*data.qte/data.ca)*100:null;
              const partCA=caTotal>0?(data.ca/caTotal)*100:0;
              return(<tr key={nom}>
                <td style={{...g.TD,color:i<3?T.gold:T.muted,fontWeight:i<3?700:400}}>{i+1}</td>
                <td style={{...g.TD,fontWeight:600}}>{nom}</td>
                <td style={g.TD}>{data.famille?<span style={g.tag(T.muted)}>{data.famille}</span>:"—"}</td>
                <td style={g.TD}>{data.qte}</td>
                <td style={{...g.TD,color:T.green,fontWeight:600}}>{fmt(data.ca)}</td>
                <td style={g.TD}><div style={{display:"flex",gap:5,alignItems:"center"}}><div style={{width:40,height:4,borderRadius:2,background:T.faint,overflow:"hidden"}}><div style={{width:`${partCA}%`,height:"100%",background:T.gold}}/></div><span style={{fontSize:9,color:T.muted}}>{partCA.toFixed(1)}%</span></div></td>
                <td style={g.TD}>{fcR!=null?<span style={g.badge(fcR>35?T.red:fcR>28?T.ember:T.green)}>{pct(fcR)}</span>:"—"}</td>
              </tr>);
            })}</tbody>
          </table>
          <div style={{marginTop:12}}>
            <div style={g.sec}>Périodes importées</div>
            {ventes.map(v=>(
              <div key={v.id} style={{display:"flex",gap:10,padding:"8px 0",borderBottom:`1px solid ${T.border}22`,alignItems:"center"}}>
                <span style={{fontSize:11,flex:1}}>{v.date_min} → {v.date_max}</span>
                <span style={g.badge(T.green)}>{fmt(v.ca_ht)}</span>
                <span style={g.badge(T.blue)}>{(v.lignes||[]).length} lignes</span>
                <button onClick={()=>deleteVente(v.id)} style={{...g.btn("red"),padding:"2px 7px",fontSize:9}}>✕</button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
//  INVENTAIRE
// ════════════════════════════════════════════════════════════════
function Inventaire({produits,upsertProduit,showToast}) {
  const [inv,setInv]=useState(()=>produits.map(p=>({id:p.id,reel:Number(p.stock)})));
  const [catF,setCatF]=useState("Tous");
  useEffect(()=>setInv(prev=>produits.map(p=>{const ex=prev.find(x=>x.id===p.id);return{id:p.id,reel:ex?ex.reel:Number(p.stock)};})),[produits.length]);
  const filtered=produits.filter(p=>catF==="Tous"||p.cat===catF);
  const total=produits.reduce((a,p)=>{const r=inv.find(x=>x.id===p.id);return a+Number(p.prix)*(r?r.reel:0);},0);
  const ecart=produits.reduce((a,p)=>{const r=inv.find(x=>x.id===p.id);return a+Math.abs((r?r.reel:0)-Number(p.stock))*Number(p.prix);},0);
  const setReel=(id,v)=>setInv(inv.map(x=>x.id===id?{...x,reel:parseFloat(v)||0}:x));
  async function valider(){
    for(const p of produits){const r=inv.find(x=>x.id===p.id);if(r)await upsertProduit({...p,stock:r.reel});}
    showToast("Inventaire validé → Supabase ✓");
  }
  function exportCSV(){
    const rows=[["Produit","Cat.","Fournisseur","Unité","Théorique","Réel","Écart","Valeur"]];
    produits.forEach(p=>{const r=inv.find(x=>x.id===p.id);const reel=r?r.reel:0;rows.push([p.nom,p.cat,p.four,p.unite,p.stock,reel,(reel-Number(p.stock)).toFixed(2),(Number(p.prix)*reel).toFixed(2)]);});
    const a=Object.assign(document.createElement("a"),{href:URL.createObjectURL(new Blob(["\uFEFF"+rows.map(r=>r.map(v=>`"${v}"`).join(";")).join("\n")],{type:"text/csv;charset=utf-8"})),download:`inventaire_${today()}.csv`});
    a.click();showToast("CSV exporté ✓");
  }
  return (
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr auto",gap:14}}>
        <div style={g.card({padding:14})}><div style={{fontFamily:"'Fraunces',serif",fontSize:20,fontWeight:700,color:T.gold}}>{fmt(total)}</div><div style={{fontSize:9,color:T.muted,letterSpacing:1.5,textTransform:"uppercase"}}>Valeur stock réel</div></div>
        <div style={g.card({padding:14})}><div style={{fontFamily:"'Fraunces',serif",fontSize:20,fontWeight:700,color:ecart>200?T.red:T.ember}}>{fmt(ecart)}</div><div style={{fontSize:9,color:T.muted,letterSpacing:1.5,textTransform:"uppercase"}}>Écart de valeur</div></div>
        <div style={{display:"flex",flexDirection:"column",gap:8,justifyContent:"center"}}>
          <button style={{...g.btn("gold"),padding:10}} onClick={valider}>✓ Valider → Supabase</button>
          <button style={{...g.btn(),padding:10}} onClick={exportCSV}>↓ CSV</button>
        </div>
      </div>
      <div style={g.card({padding:12})}><select style={{...g.inp(),maxWidth:160}} value={catF} onChange={e=>setCatF(e.target.value)}>{["Tous",...CATS].map(c=><option key={c}>{c}</option>)}</select></div>
      <div style={g.card({padding:0,overflow:"hidden"})}>
        <table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead><tr style={{background:T.surface}}>{["Produit","Cat.","Unité","Théorique","Réel","Écart","Valeur"].map(h=><th key={h} style={g.TH}>{h}</th>)}</tr></thead>
          <tbody>{filtered.map(p=>{const r=inv.find(x=>x.id===p.id);const reel=r?r.reel:0;const e=reel-Number(p.stock);return(
            <tr key={p.id}>
              <td style={{...g.TD,fontWeight:600}}>{p.nom}</td>
              <td style={g.TD}><span style={g.tag(T.cat[p.cat]||T.muted)}>{p.cat}</span></td>
              <td style={{...g.TD,color:T.muted}}>{p.unite}</td>
              <td style={{...g.TD,color:T.muted}}>{p.stock}</td>
              <td style={g.TD}><input style={{...g.inp(),width:88}} type="number" value={reel} onChange={ev=>setReel(p.id,ev.target.value)}/></td>
              <td style={g.TD}><span style={{color:e<-0.01?T.red:e>0.01?T.green:T.muted,fontWeight:Math.abs(e)>0.01?700:400,fontSize:12}}>{e>0?"+":""}{e.toFixed(2)}</span></td>
              <td style={{...g.TD,color:T.gold,fontWeight:600}}>{fmt(Number(p.prix)*reel)}</td>
            </tr>
          );})}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
//  NÉGOCE
// ════════════════════════════════════════════════════════════════
function Negoce({produits,cmdHist,showToast}) {
  const [periode,setPeriode]=useState(90);
  const [fourSel,setFourSel]=useState("Tous");
  const [generating,setGenerating]=useState(false);
  const [rapport,setRapport]=useState("");
  const [emailFour,setEmailFour]=useState("");
  const fours=[...new Set(produits.map(p=>p.four))];

  const stats=useMemo(()=>{
    const cutoff=new Date(Date.now()-periode*86400000).toISOString().split("T")[0];
    const cmdsOk=cmdHist.filter(c=>c.date>=cutoff);
    return fours.map(four=>{
      const cmds=cmdsOk.filter(c=>c.four===four);
      const totalAchats=cmds.reduce((a,c)=>a+Number(c.total),0);
      const prods=produits.filter(p=>p.four===four);
      const hausses=prods.filter(p=>Number(p.prix)>Number(p.prix_prev)*1.05);
      const valStock=prods.reduce((a,p)=>a+Number(p.prix)*Number(p.stock),0);
      const evoPrix=prods.length?prods.reduce((a,p)=>a+((Number(p.prix)-Number(p.prix_prev))/Number(p.prix_prev)*100),0)/prods.length:0;
      return{four,totalAchats,nbCommandes:cmds.length,nbProduits:prods.length,hausses,valStock,evoPrix,prods,cmds};
    }).sort((a,b)=>b.totalAchats-a.totalAchats);
  },[cmdHist,produits,periode,fours]);

  const totalGlobal=stats.reduce((a,s)=>a+s.totalAchats,0);
  const sel=fourSel==="Tous"?null:stats.find(s=>s.four===fourSel);

  async function genRapport(){
    const tgt=sel||{four:"tous fournisseurs",totalAchats:totalGlobal,nbCommandes:cmdHist.length,nbProduits:produits.length,hausses:produits.filter(p=>Number(p.prix)>Number(p.prix_prev)*1.05),evoPrix:0,prods:produits};
    setGenerating(true);
    const lignes=tgt.prods.map(p=>`- ${p.nom} (${p.cat}) : ${fmt(p.prix)}/${p.unite}${Number(p.prix)>Number(p.prix_prev)*1.05?" ⚠ hausse +"+((Number(p.prix)-Number(p.prix_prev))/Number(p.prix_prev)*100).toFixed(1)+"%":""}`).join("\n");
    try{
      const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:800,messages:[{role:"user",content:`Gestionnaire achats Favela Restaurant Bordeaux. Rapport négociation pour ${tgt.four}.\n\nDonnées :\n- Volume ${periode}j : ${fmt(tgt.totalAchats)}\n- Commandes : ${tgt.nbCommandes}\n- Références : ${tgt.nbProduits}\n- Hausses : ${tgt.hausses.length}\n\nProduits :\n${lignes}\n\nGénère : 1) Position client percutante 2) Arguments négo (3-4 points) 3) Objectifs remises 4) Email RDV. Direct et factuel.`}]})});
      const data=await res.json();setRapport(data.content.map(c=>c.text||"").join(""));
    }catch{
      setRapport(`## ${tgt.four} — Analyse\n\n**Position :** ${fmt(tgt.totalAchats)} d'achats / ${periode}j · ${tgt.nbCommandes} commandes · ${tgt.nbProduits} références.\n\n**Arguments :**\n- Régularité et fidélité\n- Volume significatif\n- ${tgt.hausses.length} hausse(s) sans contrepartie\n\n**Objectifs :** -3 à -5% remise volume / gel des prix 3 mois\n\n**Email :**\nObjet : Revue partenariat — Favela Restaurant\n\nBonjour, nous souhaitons revoir nos conditions. ${fmt(tgt.totalAchats)} d'achats sur ${periode}j méritent une discussion tarifaire.\n\nL'équipe Favela`);
    }
    setGenerating(false);
  }

  return (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <div style={g.card({padding:14})}>
        <div style={{display:"flex",gap:20,flexWrap:"wrap",alignItems:"flex-start"}}>
          <div>
            <div style={{fontSize:9,color:T.muted,letterSpacing:1.5,marginBottom:6,textTransform:"uppercase"}}>Période</div>
            <div style={{display:"flex",gap:5}}>
              {[[30,"30j"],[60,"60j"],[90,"90j"],[180,"6m"],[365,"1an"]].map(([v,l])=>(
                <button key={v} onClick={()=>setPeriode(v)} style={{padding:"5px 11px",borderRadius:5,border:`1px solid ${periode===v?T.gold:T.border}`,background:periode===v?T.gold+"20":"transparent",color:periode===v?T.gold:T.muted,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>{l}</button>
              ))}
            </div>
          </div>
          <div>
            <div style={{fontSize:9,color:T.muted,letterSpacing:1.5,marginBottom:6,textTransform:"uppercase"}}>Fournisseur</div>
            <div style={{display:"flex",gap:5}}>
              {["Tous",...fours].map(f=>(
                <button key={f} onClick={()=>setFourSel(f)} style={{padding:"5px 11px",borderRadius:5,border:`1px solid ${fourSel===f?T.gold:T.border}`,background:fourSel===f?T.gold+"20":"transparent",color:fourSel===f?T.gold:T.muted,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>{f}</button>
              ))}
            </div>
          </div>
          <button style={{...g.btn("gold"),marginLeft:"auto"}} onClick={genRapport} disabled={generating}>{generating?"⏳ IA…":"⚡ Rapport IA"}</button>
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(210px,1fr))",gap:14}}>
        {stats.map(s=>{
          const part=totalGlobal>0?(s.totalAchats/totalGlobal)*100:0;
          const selected=fourSel===s.four;
          return(<div key={s.four} onClick={()=>setFourSel(fourSel===s.four?"Tous":s.four)} style={g.card({cursor:"pointer",border:`1px solid ${selected?T.gold+"66":s.hausses.length>0?T.red+"44":T.border}`,background:selected?T.gold+"0e":T.card})}>
            <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:10}}>
              <div style={{fontFamily:"'Fraunces',serif",fontSize:14,fontWeight:700,color:selected?T.gold:T.text}}>{s.four}</div>
              {s.hausses.length>0&&<span style={g.badge(T.red)}>⚠ {s.hausses.length}</span>}
            </div>
            <div style={{fontFamily:"'Fraunces',serif",fontSize:24,fontWeight:700,color:selected?T.gold:T.green,marginBottom:2}}>{fmt(s.totalAchats)}</div>
            <div style={{fontSize:9,color:T.muted,letterSpacing:1.2,marginBottom:10,textTransform:"uppercase"}}>Volume / {periode}j</div>
            <div style={{height:4,background:T.faint,borderRadius:2,marginBottom:10}}><div style={{width:`${part}%`,height:"100%",background:selected?T.gold:T.green,borderRadius:2}}/></div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:7}}>
              {[["Commandes",s.nbCommandes],["Références",s.nbProduits],["Val. stock",fmt(s.valStock)],["Évol. prix",(s.evoPrix>0?"+":"")+s.evoPrix.toFixed(1)+"%"]].map(([l,v])=>(
                <div key={l} style={{background:T.surface,borderRadius:5,padding:"5px 8px"}}>
                  <div style={{fontSize:12,fontWeight:700,color:l==="Évol. prix"&&s.evoPrix>3?T.red:T.text}}>{v}</div>
                  <div style={{fontSize:9,color:T.muted}}>{l}</div>
                </div>
              ))}
            </div>
            <div style={{marginTop:8,fontSize:9,color:T.muted}}>Part budget : <span style={{color:T.gold,fontWeight:700}}>{part.toFixed(1)}%</span></div>
            <div style={{marginTop:8,padding:"8px 10px",background:T.gold+"12",borderRadius:5,border:`1px solid ${T.gold}22`}}>
              <div style={{fontSize:9,color:T.gold,marginBottom:3}}>Économies potentielles</div>
              {[[3,"3m"],[5,"6m"]].map(([p_,l])=>(
                <div key={p_} style={{fontSize:10,color:T.muted}}>-{p_}% → <span style={{color:T.green,fontWeight:700}}>{fmt(s.totalAchats*(p_/100))}</span> ({l})</div>
              ))}
            </div>
          </div>);
        })}
      </div>

      {sel&&(
        <div style={{display:"grid",gridTemplateColumns:"1.2fr 1fr",gap:18}}>
          <div style={g.card()}>
            <div style={g.sec}>Détail — {sel.four}</div>
            <table style={{width:"100%",borderCollapse:"collapse"}}>
              <thead><tr>{["Produit","Cat.","Prix","Préc.","Évol.","Stock","Valeur"].map(h=><th key={h} style={g.TH}>{h}</th>)}</tr></thead>
              <tbody>{sel.prods.sort((a,b)=>Number(b.prix)*Number(b.stock)-Number(a.prix)*Number(a.stock)).map(p=>{
                const d=((Number(p.prix)-Number(p.prix_prev))/Number(p.prix_prev)*100);const h=d>5;
                return(<tr key={p.id}>
                  <td style={{...g.TD,fontWeight:600}}>{p.nom}</td>
                  <td style={g.TD}><span style={g.tag(T.cat[p.cat]||T.muted)}>{p.cat}</span></td>
                  <td style={{...g.TD,color:h?T.red:T.text,fontWeight:h?700:400}}>{fmt(p.prix)}</td>
                  <td style={{...g.TD,color:T.muted,textDecoration:h?"line-through":"none"}}>{fmt(p.prix_prev)}</td>
                  <td style={g.TD}>{Math.abs(d)>0.5?<span style={g.badge(d>0?T.red:T.green)}>{d>0?"▲":"▼"}{Math.abs(d).toFixed(1)}%</span>:"—"}</td>
                  <td style={{...g.TD,color:T.muted}}>{p.stock} {p.unite}</td>
                  <td style={{...g.TD,color:T.gold,fontWeight:600}}>{fmt(Number(p.prix)*Number(p.stock))}</td>
                </tr>);
              })}</tbody>
            </table>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <div style={g.card({padding:14})}>
              <div style={g.sec}>Arguments</div>
              {[{icon:"💰",l:"Volume",v:fmt(sel.totalAchats),s:`/ ${periode}j`},{icon:"📦",l:"Commandes",v:sel.nbCommandes,s:`moy ${fmt(sel.totalAchats/Math.max(1,sel.nbCommandes))}`},{icon:"🏷",l:"Hausses",v:`${sel.hausses.length} produit${sel.hausses.length>1?"s":""}`,s:sel.hausses.length?sel.hausses.map(p=>p.nom).slice(0,2).join(", "):"Aucune"},{icon:"📊",l:"Références",v:sel.nbProduits,s:"actives"}].map(({icon,l,v,s})=>(
                <div key={l} style={{display:"flex",gap:10,padding:"7px 0",borderBottom:`1px solid ${T.border}22`,alignItems:"center"}}>
                  <span style={{fontSize:16}}>{icon}</span>
                  <div style={{flex:1}}><div style={{fontSize:12,fontWeight:600}}>{l}</div><div style={{fontSize:10,color:T.muted}}>{s}</div></div>
                  <span style={{fontSize:13,fontWeight:700,color:T.gold}}>{v}</span>
                </div>
              ))}
            </div>
            <div style={g.card({padding:14})}>
              <div style={g.sec}>Historique</div>
              {sel.cmds.length===0?<div style={{color:T.muted,fontSize:12}}>Aucune commande sur la période</div>:sel.cmds.map(c=>(
                <div key={c.id} style={{padding:"7px 0",borderBottom:`1px solid ${T.border}22`}}>
                  <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:3}}>
                    <span style={{fontSize:11,color:T.muted}}>{c.date}</span>
                    <span style={g.badge(c.statut==="Livré"?T.green:T.ember)}>{c.statut}</span>
                    <span style={{marginLeft:"auto",fontSize:12,fontWeight:700,color:T.gold}}>{fmt(c.total)}</span>
                  </div>
                  <div style={{fontSize:10,color:T.muted}}>{(c.lignes||[]).map(l=>l.nom).join(" · ")}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {rapport&&(
        <div style={g.card()}>
          <div style={{display:"flex",gap:10,marginBottom:14,alignItems:"center"}}>
            <div style={g.sec}>Rapport IA — {fourSel}</div>
            <div style={{display:"flex",gap:8,marginLeft:"auto"}}>
              <input style={{...g.inp(),maxWidth:220}} placeholder="Email commercial…" value={emailFour} onChange={e=>setEmailFour(e.target.value)}/>
              {emailFour&&<button style={g.btn("ember")} onClick={()=>{const lines=rapport.split("\n");const idx=lines.findIndex(l=>l.toLowerCase().includes("objet"));const body=idx>=0?lines.slice(idx).join("\n"):rapport.substring(0,600);window.open("mailto:"+emailFour+"?subject="+encodeURIComponent("Revue partenariat — Favela Restaurant")+"&body="+encodeURIComponent(body));}}>✉</button>}
            </div>
          </div>
          <div style={{background:T.surface,borderRadius:8,padding:20,fontSize:12,lineHeight:1.8,whiteSpace:"pre-wrap",color:T.text,border:`1px solid ${T.border}`}}>{rapport}</div>
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
//  COMMANDE
// ════════════════════════════════════════════════════════════════
function Commande({produits,cmdHist,addCommande,updateCommande,deleteCommande,showToast}) {
  const [fourSel,setFourSel]=useState("Metro");
  const [selected,setSelected]=useState({});
  const [qtes,setQtes]=useState({});
  const [email,setEmail]=useState("");
  const [emailBody,setEmailBody]=useState("");
  const [generating,setGenerating]=useState(false);
  const [modeAuto,setModeAuto]=useState(false);
  const [onglet,setOnglet]=useState("nouvelle");

  const fours=[...new Set(produits.map(p=>p.four))];
  const prodsFour=produits.filter(p=>p.four===fourSel);
  const critiques=prodsFour.filter(p=>Number(p.stock)<=Number(p.seuil)*1.5);
  const lignes=prodsFour.filter(p=>selected[p.id]);
  const total=lignes.reduce((a,p)=>a+Number(p.prix)*(parseFloat(qtes[p.id])||0),0);

  useEffect(()=>{
    if(modeAuto){const sel={};const q={};critiques.forEach(p=>{sel[p.id]=true;q[p.id]=Math.ceil(Number(p.seuil)*3-Number(p.stock));});setSelected(sel);setQtes(q);}
  },[modeAuto,fourSel]);

  async function genEmail(){
    if(!lignes.length)return;setGenerating(true);
    const liste=lignes.map(p=>`- ${p.nom} : ${qtes[p.id]||"?"} ${p.unite} (réf. ${fmt(p.prix)})`).join("\n");
    try{
      const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:500,messages:[{role:"user",content:`Email commande Favela Restaurant pour ${fourSel}.\n\nProduits:\n${liste}\n\nProfessionnel, concis, livraison 48h. "Objet :" en premier.`}]})});
      const data=await res.json();setEmailBody(data.content.map(c=>c.text||"").join(""));
    }catch{
      setEmailBody("Objet : Commande Favela – "+new Date().toLocaleDateString("fr-FR")+"\n\nMadame, Monsieur,\n\nNous souhaitons commander :\n\n"+lignes.map(p=>`- ${p.nom} : ${qtes[p.id]||"?"} ${p.unite}`).join("\n")+"\n\nMerci de confirmer disponibilité et délai (48h).\n\nL'équipe Favela Restaurant");
    }
    setGenerating(false);
  }

  async function sendEmail(){
    const subj=emailBody.split("\n").find(l=>l.startsWith("Objet :"))?.replace("Objet :","").trim()||"Commande Favela";
    window.open("mailto:"+email+"?subject="+encodeURIComponent(subj)+"&body="+encodeURIComponent(emailBody));
    await addCommande({date:today(),four:fourSel,total,statut:"En cours",lignes:lignes.map(p=>({nom:p.nom,qte:parseFloat(qtes[p.id])||0,pu:Number(p.prix)}))});
    showToast("Commande envoyée → Supabase ✓");
  }

  return (
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <div style={g.card({padding:12})}>
        <div style={{display:"flex",gap:8}}>
          {[["nouvelle","Nouvelle commande"],["historique","Historique"]].map(([id,label])=>(
            <button key={id} onClick={()=>setOnglet(id)} style={{padding:"7px 16px",borderRadius:6,border:`1px solid ${onglet===id?T.gold:T.border}`,background:onglet===id?T.gold+"20":"transparent",color:onglet===id?T.gold:T.muted,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>{label}{id==="historique"&&cmdHist.length>0?` (${cmdHist.length})`:""}</button>
          ))}
        </div>
      </div>

      {onglet==="nouvelle"&&(
        <>
          <div style={g.card({padding:12})}>
            <div style={{display:"flex",gap:10,alignItems:"center"}}>
              <div style={{display:"flex",gap:5}}>{fours.map(f=><button key={f} onClick={()=>{setFourSel(f);setSelected({});setEmailBody("");}} style={{padding:"5px 12px",borderRadius:5,border:`1px solid ${fourSel===f?T.gold:T.border}`,background:fourSel===f?T.gold+"20":"transparent",color:fourSel===f?T.gold:T.muted,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>{f}</button>)}</div>
              <label style={{fontSize:11,color:T.muted,cursor:"pointer",display:"flex",gap:6,alignItems:"center",marginLeft:"auto"}}>
                <input type="checkbox" checked={modeAuto} onChange={e=>setModeAuto(e.target.checked)}/> Auto critiques
              </label>
            </div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:18}}>
            <div style={g.card()}>
              <div style={{display:"flex",gap:8,marginBottom:12,alignItems:"center"}}>
                <div style={g.sec}>{fourSel}</div>
                {critiques.length>0&&<span style={g.badge(T.red)}>{critiques.length} critique{critiques.length>1?"s":""}</span>}
              </div>
              {prodsFour.map(p=>{const sel=!!selected[p.id];const crit=Number(p.stock)<=Number(p.seuil);return(
                <div key={p.id} onClick={()=>setSelected(s=>({...s,[p.id]:!s[p.id]}))} style={{display:"grid",gridTemplateColumns:"auto 1fr auto auto",gap:8,alignItems:"center",padding:"8px 10px",borderRadius:7,cursor:"pointer",background:sel?T.gold+"12":crit?T.red+"08":T.surface,border:`1px solid ${sel?T.gold+"44":crit?T.red+"33":T.border}`,marginBottom:6}}>
                  <div style={{width:16,height:16,borderRadius:3,border:`1.5px solid ${sel?T.gold:T.border}`,background:sel?T.gold:"transparent",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,color:T.bg}}>{sel?"✓":""}</div>
                  <div><div style={{fontSize:11,fontWeight:600}}>{p.nom}{crit?" ⚠":""}</div><div style={{fontSize:9,color:T.muted}}>{fmt(p.prix)}/{p.unite} · stock:{p.stock}</div></div>
                  <span style={g.tag(T.cat[p.cat]||T.muted)}>{p.cat}</span>
                  {sel&&<input type="number" placeholder="Qté" style={{...g.inp(),width:64,fontSize:11}} value={qtes[p.id]||""} onClick={e=>e.stopPropagation()} onChange={e=>setQtes(q=>({...q,[p.id]:e.target.value}))}/>}
                </div>
              );})}
              {lignes.length>0&&<div style={{marginTop:10,padding:"10px 14px",background:T.gold+"12",borderRadius:7,border:`1px solid ${T.gold}33`,display:"flex",justifyContent:"space-between"}}><span style={{color:T.muted,fontSize:11}}>{lignes.length} article{lignes.length>1?"s":""}</span><span style={{color:T.gold,fontWeight:700}}>Estimé : {fmt(total)}</span></div>}
            </div>
            <div style={g.card()}>
              <div style={g.sec}>Email de commande</div>
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                <input style={g.inp()} placeholder="Email fournisseur…" value={email} onChange={e=>setEmail(e.target.value)}/>
                <button style={{...g.btn("gold"),padding:10}} onClick={genEmail} disabled={generating||!lignes.length}>{generating?"⏳ IA…":"⚡ Générer"}</button>
                {emailBody&&<><textarea style={{...g.inp(),height:260,lineHeight:1.7,fontSize:11}} value={emailBody} onChange={e=>setEmailBody(e.target.value)}/><button style={{...g.btn("ember"),padding:10}} onClick={sendEmail}>✉ Envoyer + Enregistrer → Supabase</button></>}
              </div>
            </div>
          </div>
        </>
      )}

      {onglet==="historique"&&(
        <div style={g.card()}>
          <div style={g.sec}>Historique — {cmdHist.length} commandes · {fmt(cmdHist.reduce((a,c)=>a+Number(c.total),0))} total</div>
          {cmdHist.length===0?<div style={{color:T.muted,fontSize:12,textAlign:"center",padding:40}}>Aucune commande</div>:
            <table style={{width:"100%",borderCollapse:"collapse"}}>
              <thead><tr>{["Date","Fournisseur","Articles","Montant","Statut","Action"].map(h=><th key={h} style={g.TH}>{h}</th>)}</tr></thead>
              <tbody>{cmdHist.map(c=>(
                <tr key={c.id}>
                  <td style={{...g.TD,fontSize:11,color:T.muted}}>{c.date}</td>
                  <td style={{...g.TD,fontWeight:600}}>{c.four}</td>
                  <td style={{...g.TD,fontSize:10,color:T.muted,maxWidth:200}}>{(c.lignes||[]).map(l=>l.nom+" ×"+l.qte).join(" · ")}</td>
                  <td style={{...g.TD,color:T.gold,fontWeight:700}}>{fmt(c.total)}</td>
                  <td style={g.TD}><span style={g.badge(c.statut==="Livré"?T.green:c.statut==="Annulé"?T.red:T.ember)}>{c.statut}</span></td>
                  <td style={g.TD}>
                    <div style={{display:"flex",gap:5}}>
                      {c.statut==="En cours"&&<button style={{...g.btn("green"),padding:"3px 8px",fontSize:9}} onClick={()=>updateCommande(c.id,{statut:"Livré"})}>✓ Livré</button>}
                      <button style={{...g.btn("red"),padding:"3px 8px",fontSize:9}} onClick={()=>deleteCommande(c.id)}>✕</button>
                    </div>
                  </td>
                </tr>
              ))}</tbody>
            </table>}
        </div>
      )}
    </div>
  );
}
